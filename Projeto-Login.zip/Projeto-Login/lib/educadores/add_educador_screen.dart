
import 'package:flutter/material.dart';

class AddEducadorScreen extends StatefulWidget {
const AddEducadorScreen({super.key});

@override
State<AddEducadorScreen> createState() => _AddEducadorScreenState();
}

class _AddEducadorScreenState extends State<AddEducadorScreen> {
final _formKey = GlobalKey<FormState>();
String? _perfilSelecionado;

)

@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(title: const Text('Adicionar Educador')),
body: Padding(
padding: const EdgeInsets.all(16.0),
child: Form(
key: _formKey,
child: ListView(
children: [
TextFormField(
),
const SizedBox(height: 16),
TextFormField(
),
const SizedBox(height: 16),
DropdownButtonFormField<String>(
value: _perfilSelecionado,
hint: const Text('Selecione o Perfil'),
items: const [
DropdownMenuItem(value: 'Professor', child: Text('Professor')),
DropdownMenuItem(value: 'Coordenador', child: Text('Coordenador')),
],
onChanged: (value) {
setState(() {
_perfilSelecionado = value;
});
},
validator: (value) => value == null ? 'Campo obrigatório' : null,
),


if (_perfilSelecionado == 'Professor')
_buildProfessorFields(),

if (_perfilSelecionado == 'Coordenador')
_buildCoordenadorFields(),

const SizedBox(height: 24),
ElevatedButton(
onPressed: () {

},
child: const Text('Salvar'),
)
],
),
),
),
);
}

Widget _buildProfessorFields() {
return Padding(
padding: const EdgeInsets.only(top: 16.0),
child: Column(
crossAxisAlignment: CrossAxisAlignment.start,
children: [
Text('Turmas do Professor', style: Theme.of(context).textTheme.titleMedium),

const Text('Dropdown/Multi-select de turmas aqui...'),
],
),
);
}

Widget _buildCoordenadorFields() {
return Padding(
padding: const EdgeInsets.only(top: 16.0),
child: Column(
crossAxisAlignment: CrossAxisAlignment.start,
children: [
Text('Grades do Coordenador', style: Theme.of(context).textTheme.titleMedium),

const Text('Multi-select de grades aqui...'),
],
),
);
}
}